/*
 * dma2d.h
 *
 *  Created on: 30 oct. 2018
 *      Author: alexandre.ferroni
 */

#ifndef BSP_INC_DMA2_DCMI_H_
#define BSP_INC_DMA2_DCMI_H_

#include "main.h"

void dma2_dcmi_init();

#endif /* BSP_INC_DMA2_DCMI_H_ */
