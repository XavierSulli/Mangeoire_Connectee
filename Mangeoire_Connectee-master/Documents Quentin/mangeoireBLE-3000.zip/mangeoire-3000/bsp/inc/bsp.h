/*
 * bsp.h
 *
 *  Created on: 29 nov. 2018
 *      Author: Laurent
 */

#ifndef BSP_INC_BSP_H_
#define BSP_INC_BSP_H_

#include "stm32l4xx.h"

/*
 * LED driver functions
 */

#define	BLUE	0
#define WHITE	1
#define	RED		2
#define ALL		3

#define UART_BUFFER_SIZE		23

void	BSP_LED_Init	(void);
void	BSP_LED_On		(uint8_t id);
void	BSP_LED_Off		(uint8_t id);
void	BSP_LED_Toggle	(uint8_t id);


/*
 * Push-Button driver functions
 */

void	BSP_PB_Init		(void);
uint8_t	BSP_PB_GetState	(void);


/*
 * Debug Console driver functions
 */

void	BSP_Console_Init	(void);


void  BSP_ADC_Init(void);

void BSP_NVIC_Init				(void);

#endif /* BSP_INC_BSP_H_ */
