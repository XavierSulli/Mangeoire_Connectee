

/*
 * main.c
 *
 *  Created on: 29 nov. 2018
 *      Author: Mathieu
 */

#include "stm32l4xx.h"
#include <stdio.h>
#include <string.h>
#include "main.h"
#include "bsp.h"
#include "sdhc.h"
#include "ff.h"
#include "delay.h"
#include "uart.h"
#include "rtc.h"



#define	 NULL	((void *)0)
#define precision 1000000
#define MAX 850

/*
 * Local Static Functions
 */

static uint8_t SystemClock_Config	(void);

int8_t 	my_strcmp(const uint8_t *s1, const uint8_t *s2);




// global variables

			uint32_t		dcmi_dma_buffer1[10000];
			uint32_t		dcmi_dma_buffer2[10000];

			uint32_t		dcmi_dma_buffer_HQ[buffer_HQ_size];

			uint8_t			frame_irq;
			uint8_t			command_irq;
			uint8_t 		snap_irq;
			uint8_t 		uart_img_irq;
			uint8_t 		uart_rx_irq;
			uint8_t	 		cap_start;

			uint8_t	     console_rx_byte;
			uint8_t	     console_rx_irq = 0;

			uint8_t buffert;
			uint8_t buffer[MAX];

volatile	uint8_t			process_rtc_sync;					// LPUART1 RX DMA TC for RTC Sync messages

extern 		uint8_t			uart_buffer[UART_BUFFER_SIZE];		// Buffer to store 8-bit LPUART1 RX incoming data

extern		rtcc_t			now;

uint32_t nbr_data_uart; //number of data to send
uint32_t prev_data_uart;//number of data to send, used if snap requested

FRESULT		fresult;
FATFS		fs;
FATFS		*pfs;
FIL			myfile;
uint32_t	free_clust, total_sect, free_sect;

DIR			home_dir;
FILINFO		fno;
uint8_t		filename[16];		// Example : "REC_000.IMA" (+\0)

uint16_t	file_id;			// Beware! Up to 999 (file id) -> 16-bit required
uint16_t	exist_id;
uint16_t	file_count;
uint8_t		cmp;

uint8_t		txtbuf[32];
uint8_t		logString[83];

// Loop and index counters
uint8_t     led;
uint8_t     debug;
uint32_t	i;
uint32_t 	state = 0;
uint16_t	timeout;




/*
 * Project Entry Point
 */

int main()
{



	// Configure System Clock for 80MHz from 4MHz MSI (with LSE calibration)
	while (SystemClock_Config() != 0);

	delay_ms(100);




	DELAY_TIM2_init();
	// Make-sure NVIC Priority Grouping is 0 (16 priority levels, no sub-priority)
	//NVIC_SetPriorityGrouping((uint32_t) 0);
	NVIC_SetPriority(TIM2_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2);
	NVIC_EnableIRQ(TIM2_IRQn);


	//configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1


	// Initialize LED and USER Button
	BSP_LED_Init();
	BSP_PB_Init();



	// Initialize Debug Console
	BSP_Console_Init();
	uart_init();








	my_printf("\033[2J");
	my_printf("\033[0;0H");
	my_printf("\033[37m");
	my_printf("\r\nConsole Ready!\r\n");
	my_printf("SYSCLK = %d Hz\r\n", SystemCoreClock);



	// Welcome message
	my_printf("\r\n");
	my_printf("---------------------------------------\r\n");
	my_printf("-              BLE 22800              -\r\n");
	my_printf("-  Polytech MEA -  Montpellier 2020   -\r\n");
	my_printf("- Firmware version 1.1.5 (18/06/2020) -\r\n");
	my_printf("---------------------------------------\r\n");
	my_printf("\r\n");

	BSP_ADC_Init();

	DELAY_TIM_init();

	delay_ms(500);

	HCI_TL_SPI_Init();

	BlueNRG_MS_Init();


	while(1){
	BlueNRG_MS_Process();

	delay_ms(200);
	}





}









/*
 * 	Clock configuration for the Nucleo STM32L496ZG board
 * 	MSI clock						-> 4 MHz (with LSE calibration)
 *	SYSCLK, AHB, APB1, APB2			-> 80MHz
 *
 *  PA8 as MCO with MSI output 		-> 4MHz
 *
 */









int8_t my_strcmp(const uint8_t *s1, const uint8_t *s2)
{
  while (*s1 != '\0' && *s1 == *s2)
    {
      s1++;
      s2++;
    }
  return (*(uint8_t *) s1) - (*(uint8_t *) s2);
}

static uint8_t SystemClock_Config()
{
	uint32_t	status;
	uint32_t	timeout;
	uint32_t	temp;

	// Start LSE (for MSI PLL hardware calibration)
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;	// Enable writing of Battery/Backup domain
	PWR->CR1 |= PWR_CR1_DBP;
	RCC->BDCR &= ~RCC_BDCR_LSEDRV;			// Set LSE driving to medium effort
	RCC->BDCR |= (0x03 <<3);
	RCC->BDCR |= RCC_BDCR_LSEON;			// Start LSE

	// Wait until LSE is ready
	timeout = 1000;

	do
	{
		status = RCC->BDCR & RCC_BDCR_LSERDY;
		timeout--;
	} while ((status == 0) && (timeout > 0));
	if (timeout == 0) return (1);	// LSE error

	// Enable MSI PLL auto-calibration
	RCC->CR |= RCC_CR_MSIPLLEN;

	// Set MSI range
	RCC->CR |= RCC_CR_MSIRANGE_6;	// For 4MHz
	RCC->CR |= RCC_CR_MSIRGSEL;		// MSI range is provided by CR register

	// Start MSI
	RCC->CR |= RCC_CR_MSION;

	// Wait until MSI is ready
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_MSIRDY;
		timeout--;
	} while ((status == 0) && (timeout >0));

	if (timeout == 0) return (2);	// MSI error


	// Make sure PLL is off before configuration
	RCC->CR &= ~RCC_CR_PLLON;

	// Wait until PLL is off
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_PLLRDY;
		timeout--;
	} while ((status != 0) && (timeout > 0));

	if (timeout == 0) return (3);	// PLL error


	// Configure the main PLL for 80MHz output
	//			    PLL_M=1	     PLL_N=40     PLL_P=7       PLL_Q=4        PLL_R=2
	RCC->PLLCFGR = (0x00 <<4) | (0x28 <<8) | (0x00 <<17) | (0x01 <<21) |  (0x00 <<25);

	// Set MSI as PLL input
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLSRC_MSI;

	// Enable PLL
	RCC->CR |= RCC_CR_PLLON;

	// Enable PLL_R output (system clock)
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLREN;

	// Set voltage range 1 as MCU will run at 80MHz
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;
	temp = PWR->CR1;
	temp |=  (0x01<<9);
	temp &= ~(0x02<<9);
	PWR->CR1 = temp;

	// Wait until VOSF bit is cleared (regulator ready)
	timeout = 1000;

	do
	{
		status = PWR->SR2 & PWR_SR2_VOSF;
		timeout--;
	} while ((status != 0) && (timeout > 0));

	if (timeout == 0) return (4);	// PWR error

	// Configure FLASH with prefetch and 4 WS
	FLASH->ACR |= FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_4WS;

	// Configure AHB/APB prescalers
	// AHB  Prescaler = /1	-> 80 MHz
	// APB1 Prescaler = /1  -> 80 MHz
	// APB2 Prescaler = /2  -> 40 MHz
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1;
	RCC->CFGR |= RCC_CFGR_PPRE2_DIV1;
	RCC->CFGR |= RCC_CFGR_PPRE1_DIV1;

	// Wait until PLL is ready
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_PLLRDY;
		timeout--;
	} while ((status == 0) && (timeout > 0));

	if (timeout == 0) return (3);	// PLL error


	// Select the main PLL as system clock source
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	//  Wait until PLL becomes main switch input
	timeout = 1000;

	do
	{
		status = RCC->CFGR & RCC_CFGR_SWS;
		timeout--;
	} while ((status != RCC_CFGR_SWS_PLL) && (timeout > 0));

	if (timeout == 0) return (5);	// SW error


	// Start GPIOA clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;

	// Configure PA8 as AF mode
	GPIOA->MODER &= ~(GPIO_MODER_MODER8);
	GPIOA->MODER |= (0x02 << 16);

	// Connect to MCO (AF0)
	GPIOA->AFR[1] &= ~(0x0000000F);
	GPIOA->AFR[1] |=   0x00000000;

	// Set MCO divider
	RCC->CFGR &= ~RCC_CFGR_MCOPRE;
	RCC->CFGR |= RCC_CFGR_MCOPRE_DIV1;

	// Select Master Clock Output (MCO) source
	RCC->CFGR &= ~RCC_CFGR_MCOSEL;
	RCC->CFGR |= (0x02 <<24);			// 0x01 for SYSCLK; 0x02 for MSI

	// Start RTC clock
	RCC->BDCR |= RCC_BDCR_LSCOSEL;	// Select LSE as Low Speed Clock for RTC
	RCC->BDCR |= (0x01 <<8U);		// Select LSE as RTC clock
	RCC->BDCR |= RCC_BDCR_RTCEN;	// Enable RTC clock

	// Update System core clock
	SystemCoreClockUpdate();
	return (0);
}


