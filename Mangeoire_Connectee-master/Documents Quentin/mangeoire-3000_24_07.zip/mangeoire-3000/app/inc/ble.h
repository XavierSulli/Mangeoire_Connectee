/*
 * ble.h
 *
 *  Created on: 6 avr. 2019
 *      Author: Laurent
 */

#ifndef APP_INC_BLE_H_
#define APP_INC_BLE_H_



#define BDADDR_SIZE 6




void BlueNRG_MS_Init	(void);
void BlueNRG_MS_Process	(void);


#endif /* APP_INC_BLE_H_ */
