/*
 * uart.h
 *
 *  Created on: 13 nov. 2018
 *      Author: alexandre.ferroni
 */

#ifndef BSP_INC_UART_H_
#define BSP_INC_UART_H_

#include "main.h"

void uart_init();

void uart_gps_init();

#endif /* BSP_INC_UART_H_ */
