/*
 * util.c
 *
 *  Created on: 6 avr. 2019
 *      Author: Laurent
 */

#include "util.h"
#include "hci_le.h"

uint8_t getBlueNRGVersion(uint8_t *hwVersion, uint16_t *fwVersion)
{
  uint8_t 	status;
  uint8_t 	hci_version, lmp_pal_version;
  uint16_t 	hci_revision, manufacturer_name, lmp_pal_subversion;

  status = hci_le_read_local_version(&hci_version, &hci_revision, &lmp_pal_version, &manufacturer_name, &lmp_pal_subversion);

  if (status == BLE_STATUS_SUCCESS)
  {
    *hwVersion = hci_revision >> 8;
    *fwVersion = (hci_revision & 0xFF) << 8;              	// Major Version Number
    *fwVersion |= ((lmp_pal_subversion >> 4) & 0xF) << 4; 	// Minor Version Number
    *fwVersion |= lmp_pal_subversion & 0xF;               	// Patch Version Number
  }

  return status;
}
