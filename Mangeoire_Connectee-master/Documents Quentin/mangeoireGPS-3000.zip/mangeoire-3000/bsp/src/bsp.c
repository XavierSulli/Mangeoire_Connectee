/*
 * bsp.c
 *
 *  Created on: 29 nov. 2018
 *      Author: Laurent
 */


#include <bsp.h>

/*
 * BSP_LED_Init()
 * Initialize LED pin (PC7, PB7, PB14) as  High-Speed Push-Pull Output
 * Set LED initial state to OFF
 */

void BSP_LED_Init()
{
	// Enable GPIOC clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;

	// Configure PC7 as output
	GPIOA->MODER &= ~GPIO_MODER_MODE7_Msk;
	GPIOA->MODER |= (0x01 <<GPIO_MODER_MODE7_Pos);

	// Configure PC7 as Push-Pull output
	GPIOA->OTYPER &= ~GPIO_OTYPER_OT_7;

	// Configure PC7 as High-Speed Output
	GPIOA->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED7_Msk;
	GPIOA->OSPEEDR |= (0x03 <<GPIO_OSPEEDR_OSPEED7_Pos);

	// Disable PC7 Pull-up/Pull-down
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD7_Msk;

	// Set Initial State OFF
	GPIOA->BSRR = GPIO_BSRR_BR_7;

	// Enable GPIOB clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;

	// Configure PB7, PB14 as output
	GPIOB->MODER &= ~(GPIO_MODER_MODE1_Msk | GPIO_MODER_MODE2_Msk);
	GPIOB->MODER |= (0x01 <<GPIO_MODER_MODE1_Pos) | (0x01 <<GPIO_MODER_MODE2_Pos);

	// Configure PB7, PB14 as Push-Pull output
	GPIOB->OTYPER &= ~(GPIO_OTYPER_OT_1 | GPIO_OTYPER_OT_2);

	// Configure PB7, PB14 as High-Speed Output
	GPIOB->OSPEEDR &= ~(GPIO_OSPEEDR_OSPEED1_Msk | GPIO_OSPEEDR_OSPEED2_Msk);
	GPIOB->OSPEEDR |= (0x03 <<GPIO_OSPEEDR_OSPEED1_Pos) | (0x03 <<GPIO_OSPEEDR_OSPEED2_Pos);

	// Disable PB7, PB14 Pull-up/Pull-down
	GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPD1_Msk | GPIO_PUPDR_PUPD2_Msk);

	// Set Initial State OFF
	GPIOB->BSRR = GPIO_BSRR_BR_1;
	GPIOB->BSRR = GPIO_BSRR_BR_2;
}

/*
 * BSP_LED_On()
 * Turn ON LED on PC7
 */

void BSP_LED_On(uint8_t id)
{
	switch (id)
	{
		case 0:
		{
			GPIOA->BSRR = GPIO_BSRR_BS7;
			break;
		}

		case 1:
		{
			GPIOB->BSRR = GPIO_BSRR_BS1;
			break;
		}

		case 2:
		{
			GPIOB->BSRR = GPIO_BSRR_BS2;
			break;
		}
		case 3:
		{
			GPIOA->BSRR = GPIO_BSRR_BS7;
			GPIOB->BSRR = GPIO_BSRR_BS1;
			GPIOB->BSRR = GPIO_BSRR_BS2;
			break;
		}
	}
}

/*
 * BSP_LED_Off()
 * Turn OFF LED on PA5
 */

void BSP_LED_Off(uint8_t id)
{
	switch (id)
	{
		case 0:
		{
			GPIOA->BSRR = GPIO_BSRR_BR7;
			break;
		}

		case 1:
		{
			GPIOB->BSRR = GPIO_BSRR_BR1;
			break;
		}

		case 2:
		{
			GPIOB->BSRR = GPIO_BSRR_BR2;
			break;
		}
		case 3:
		{
			GPIOA->BSRR = GPIO_BSRR_BR7;
			GPIOB->BSRR = GPIO_BSRR_BR1;
			GPIOB->BSRR = GPIO_BSRR_BR2;
			break;
		}
	}
}

/*
 * BSP_LED_Toggle()
 * Toggle LED on PA5
 */

void BSP_LED_Toggle(uint8_t id)
{
	switch (id)
	{
		case 0:
		{
			GPIOA->ODR ^= GPIO_ODR_ODR_7;
			break;
		}

		case 1:
		{
			GPIOB->ODR ^= GPIO_ODR_ODR_1;
			break;
		}

		case 2:
		{
			GPIOB->ODR ^= GPIO_ODR_ODR_2;
			break;
		}
	}
}

/*
 * BSP_PB_Init()
 * Initialize Push-Button pin (PC13) as input without Pull-up/Pull-down
 */

void BSP_PB_Init()
{
	// Enable GPIOC clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;

	// Configure PC13 as input
	GPIOC->MODER &= ~GPIO_MODER_MODE13_Msk;
	GPIOC->MODER |= (0x00 <<GPIO_MODER_MODE13_Pos);

	// Disable PC13 Pull-up/Pull-down
	GPIOC->PUPDR &= ~GPIO_PUPDR_PUPD13_Msk;
}

/*
 * BSP_PB_GetState()
 * Returns the state of the button (0=released, 1=pressed)
 */

uint8_t	BSP_PB_GetState()
{
	uint8_t state;

	if ((GPIOC->IDR & GPIO_IDR_ID13) == GPIO_IDR_ID13)
	{
		state = 1;
	}
	else
	{
		state = 0;
	}

	return state;
}

/*
 * BSP_Console_Init()
 * LPUART1 @ 115200 Full Duplex
 * 1 start - 8-bit - 1 stop
 * TX -> PG7 (AF8)
 * RX -> PG8 (AF8)
 */

void BSP_Console_Init()
{
	// Enable GPIOG clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOGEN;

	// Enable VDDIO2 (for use GPIOG)
	PWR->CR2 |= PWR_CR2_IOSV;

	// Configure PG7 and PG8 as Alternate function
	GPIOG->MODER &= ~(GPIO_MODER_MODE7_Msk | GPIO_MODER_MODE8_Msk);
	GPIOG->MODER |=  (0x02 <<GPIO_MODER_MODE7_Pos) | (0x02 <<GPIO_MODER_MODE8_Pos);

	// Setup output Push-Pull type
	GPIOG->OTYPER &= ~(GPIO_OTYPER_ODR_7 | GPIO_OTYPER_ODR_8);

	// Setup Speed to high-speed
	GPIOG->OSPEEDR &= ~(GPIO_OSPEEDER_OSPEEDR7 | GPIO_OSPEEDER_OSPEEDR8);
	GPIOG->OSPEEDR |=  (0x02 <<GPIO_OSPEEDR_OSPEED7_Pos) | (0x02 <<GPIO_OSPEEDR_OSPEED7_Pos);

	// Set PG7 and PG8 to AF8 (LPUART1)
	GPIOG->AFR[0] &= ~(0xF0000000);
	GPIOG->AFR[0] |=  (0x80000000);
	GPIOG->AFR[1] &= ~(0x0000000F);
	GPIOG->AFR[1] |=  (0x00000008);

	// Select SYSCLK (80MHz) as clock source
	RCC->CCIPR &= ~RCC_CCIPR_LPUART1SEL;
	RCC->CCIPR |=  0x01 <<RCC_CCIPR_LPUART1SEL_Pos;

	// Enable LPUART1 clock
	RCC->APB1ENR2 |= RCC_APB1ENR2_LPUART1EN;

	// Clear LPUART1 configuration (reset state)
	// 8-bit, 1 start, 1 stop, CTS/RTS disabled
	LPUART1->CR1 = 0x00000000;
	LPUART1->CR2 = 0x00000000;
	LPUART1->CR3 = 0x00000000;

	// Baud Rate = 115200 = 256*80MHz / BRR
	LPUART1->CR1 &= ~USART_CR1_OVER8;
	LPUART1->BRR = 0x02B672;

	// Enable both Transmitter and Receiver
	LPUART1->CR1 |= USART_CR1_TE | USART_CR1_RE;

	// Enable LPUART1
	LPUART1->CR1 |= USART_CR1_UE;
}

void BSP_ADC_Init()
{
	// Enable GPIOC clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;

	// Configure pin PC3 as analog
	GPIOC->MODER &= ~GPIO_MODER_MODE3_Msk;
	GPIOC->MODER |= (0x03 <<GPIO_MODER_MODE3_Pos);

	// Configure pin PB4
	GPIOB->MODER &= ~(GPIO_MODER_MODE4);
	GPIOB->MODER |= (0x01 <<GPIO_MODER_MODE4_Pos);

	GPIOB->OTYPER &= ~(GPIO_OTYPER_OT_4);

	GPIOB->OSPEEDR &= ~(GPIO_OSPEEDER_OSPEEDR4);
	GPIOB->OSPEEDR |=  (0x03 << GPIO_OSPEEDR_OSPEED4_Pos);

	GPIOB->BSRR = GPIO_BSRR_BR_4;

	// Enable ADC clock
	RCC->AHB2ENR |= RCC_AHB2ENR_ADCEN;

	// Reset ADC configuration
	ADC1->CR 	= 0x00000000;
	ADC1->CFGR  = 0x00000000;
	ADC1->CFGR2 = 0x00000000;
	ADC1->SQR1  = 0x00000000;
	ADC1->SQR2  = 0x00000000;
	ADC1->SQR3  = 0x00000000;
	ADC1->SQR4  = 0x00000000;

	// Enable continuous conversion mode
	ADC1->CFGR |= ADC_CFGR_CONT;

	// 12-bit resolution
	ADC1->CFGR |= (0x00 <<ADC_CFGR_RES_Pos);

	// Select PCLK/2 as ADC clock
	RCC->CCIPR |= (0x03 << RCC_CCIPR_ADCSEL_Pos);

	// Set sampling time to 24.5 ADC clock cycles channel 4 of PC3
	ADC1->SMPR1 |= (0x03 << ADC_SMPR1_SMP4_Pos) ;

	// Select channel & number of conversion
	ADC1->SQR1 &= ~ADC_SQR1_L; // reset value of ADC
	ADC1->SQR1 |= (0x00 << ADC_SQR1_L_Pos);// set to 1 conversion
	ADC1->SQR1 &= ~ADC_SQR1_SQ1;// reset of SQ1
	ADC1->SQR1 |= (0x04 << ADC_SQR1_SQ1_Pos);// channel 4 selection

	// Enable ADC
	ADC1->ISR |= ADC_ISR_ADRDY;
	ADC1->CR |= ADC_CR_ADEN;

}


void BSP_NVIC_Init()
{


	// Set priority level 1 for RTC interrupt
	NVIC_SetPriority(RTC_Alarm_IRQn, 1);

	// Enable RTC interrupts
	NVIC_EnableIRQ(RTC_Alarm_IRQn);
}
