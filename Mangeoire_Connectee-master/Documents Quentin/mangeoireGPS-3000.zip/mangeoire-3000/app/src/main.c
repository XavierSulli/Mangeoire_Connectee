

/*
 * main.c
 *
 *  Created on: 29 nov. 2018
 *      Author: Mathieu
 */

#include "stm32l4xx.h"
#include "main.h"
#include "bsp.h"
#include "sdhc.h"
#include "ff.h"
#include "delay.h"
#include "uart.h"
#include "rtc.h"

#define	 NULL	((void *)0)
#define precision 1000000

/*
 * Local Static Functions
 */

static uint8_t SystemClock_Config	(void);

int8_t 	my_strcmp(const uint8_t *s1, const uint8_t *s2);







/*
 * Project Entry Point
 */

int main()
{


	// Configure System Clock for 80MHz from 4MHz MSI (with LSE calibration)
	while (SystemClock_Config() != 0);



	//BSP_SDHC_SPI_Init();

	// Initialize Debug Console
	BSP_Console_Init();
	//uart_init();

	uartgps_init();

	uint8_t		rx_byte;




	my_printf("\033[2J");
	my_printf("\033[0;0H");
	my_printf("\033[37m");
	my_printf("\r\nConsole Ready!\r\n");
	my_printf("SYSCLK = %d Hz\r\n", SystemCoreClock);



	// Welcome message
	my_printf("\r\n");
	my_printf("---------------------------------------\r\n");
	my_printf("-                GPS                  -\r\n");
	my_printf("-  Polytech MEA -  Montpellier 2020   -\r\n");
	my_printf("- Firmware version 1.0.0 (25/05/2020) -\r\n");
	my_printf("---------------------------------------\r\n");
	my_printf("\r\n");

while(1)
{

	// If there is something in USART RDR register
	if ( (UART4->ISR & USART_ISR_RXNE) == USART_ISR_RXNE )
	{
		// Read and report the content of RDR
		rx_byte = UART4->RDR;
		my_printf("%c", rx_byte);
	}
}



}


/*
 * 	Clock configuration for the Nucleo STM32L496ZG board
 * 	MSI clock						-> 4 MHz (with LSE calibration)
 *	SYSCLK, AHB, APB1, APB2			-> 80MHz
 *
 *  PA8 as MCO with MSI output 		-> 4MHz
 *
 */



int8_t my_strcmp(const uint8_t *s1, const uint8_t *s2)
{
  while (*s1 != '\0' && *s1 == *s2)
    {
      s1++;
      s2++;
    }
  return (*(uint8_t *) s1) - (*(uint8_t *) s2);
}

static uint8_t SystemClock_Config()
{
	uint32_t	status;
	uint32_t	timeout;
	uint32_t	temp;

	// Start LSE (for MSI PLL hardware calibration)
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;	// Enable writing of Battery/Backup domain
	PWR->CR1 |= PWR_CR1_DBP;
	RCC->BDCR &= ~RCC_BDCR_LSEDRV;			// Set LSE driving to medium effort
	RCC->BDCR |= (0x03 <<3);
	RCC->BDCR |= RCC_BDCR_LSEON;			// Start LSE

	// Wait until LSE is ready
	timeout = 1000;

	do
	{
		status = RCC->BDCR & RCC_BDCR_LSERDY;
		timeout--;
	} while ((status == 0) && (timeout > 0));
	if (timeout == 0) return (1);	// LSE error

	// Enable MSI PLL auto-calibration
	RCC->CR |= RCC_CR_MSIPLLEN;

	// Set MSI range
	RCC->CR |= RCC_CR_MSIRANGE_6;	// For 4MHz
	RCC->CR |= RCC_CR_MSIRGSEL;		// MSI range is provided by CR register

	// Start MSI
	RCC->CR |= RCC_CR_MSION;

	// Wait until MSI is ready
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_MSIRDY;
		timeout--;
	} while ((status == 0) && (timeout >0));

	if (timeout == 0) return (2);	// MSI error


	// Make sure PLL is off before configuration
	RCC->CR &= ~RCC_CR_PLLON;

	// Wait until PLL is off
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_PLLRDY;
		timeout--;
	} while ((status != 0) && (timeout > 0));

	if (timeout == 0) return (3);	// PLL error


	// Configure the main PLL for 80MHz output
	//			    PLL_M=1	     PLL_N=40     PLL_P=7       PLL_Q=4        PLL_R=2
	RCC->PLLCFGR = (0x00 <<4) | (0x28 <<8) | (0x00 <<17) | (0x01 <<21) |  (0x00 <<25);

	// Set MSI as PLL input
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLSRC_MSI;

	// Enable PLL
	RCC->CR |= RCC_CR_PLLON;

	// Enable PLL_R output (system clock)
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLREN;

	// Set voltage range 1 as MCU will run at 80MHz
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;
	temp = PWR->CR1;
	temp |=  (0x01<<9);
	temp &= ~(0x02<<9);
	PWR->CR1 = temp;

	// Wait until VOSF bit is cleared (regulator ready)
	timeout = 1000;

	do
	{
		status = PWR->SR2 & PWR_SR2_VOSF;
		timeout--;
	} while ((status != 0) && (timeout > 0));

	if (timeout == 0) return (4);	// PWR error

	// Configure FLASH with prefetch and 4 WS
	FLASH->ACR |= FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_4WS;

	// Configure AHB/APB prescalers
	// AHB  Prescaler = /1	-> 80 MHz
	// APB1 Prescaler = /1  -> 80 MHz
	// APB2 Prescaler = /2  -> 40 MHz
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1;
	RCC->CFGR |= RCC_CFGR_PPRE2_DIV1;
	RCC->CFGR |= RCC_CFGR_PPRE1_DIV1;

	// Wait until PLL is ready
	timeout = 1000;

	do
	{
		status = RCC->CR & RCC_CR_PLLRDY;
		timeout--;
	} while ((status == 0) && (timeout > 0));

	if (timeout == 0) return (3);	// PLL error


	// Select the main PLL as system clock source
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_PLL;

	//  Wait until PLL becomes main switch input
	timeout = 1000;

	do
	{
		status = RCC->CFGR & RCC_CFGR_SWS;
		timeout--;
	} while ((status != RCC_CFGR_SWS_PLL) && (timeout > 0));

	if (timeout == 0) return (5);	// SW error


	// Start GPIOA clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;

	// Configure PA8 as AF mode
	GPIOA->MODER &= ~(GPIO_MODER_MODER8);
	GPIOA->MODER |= (0x02 << 16);

	// Connect to MCO (AF0)
	GPIOA->AFR[1] &= ~(0x0000000F);
	GPIOA->AFR[1] |=   0x00000000;

	// Set MCO divider
	RCC->CFGR &= ~RCC_CFGR_MCOPRE;
	RCC->CFGR |= RCC_CFGR_MCOPRE_DIV1;

	// Select Master Clock Output (MCO) source
	RCC->CFGR &= ~RCC_CFGR_MCOSEL;
	RCC->CFGR |= (0x02 <<24);			// 0x01 for SYSCLK; 0x02 for MSI

	// Start RTC clock
	RCC->BDCR |= RCC_BDCR_LSCOSEL;	// Select LSE as Low Speed Clock for RTC
	RCC->BDCR |= (0x01 <<8U);		// Select LSE as RTC clock
	RCC->BDCR |= RCC_BDCR_RTCEN;	// Enable RTC clock

	// Update System core clock
	SystemCoreClockUpdate();
	return (0);
}


